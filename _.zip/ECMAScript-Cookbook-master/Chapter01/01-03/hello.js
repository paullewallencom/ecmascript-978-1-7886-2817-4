export function sayHi () {
  console.log('Hello, World');
}
