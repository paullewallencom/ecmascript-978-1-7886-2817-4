import { main } from './main.js';
main();
