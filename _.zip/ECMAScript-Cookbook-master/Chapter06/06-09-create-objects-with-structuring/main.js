
export function main() {
  const prop1 = 'some value';
  const prop2 = 'some other value';
  const objectProp = { foo: 'bar' };
  const object = { prop1, prop2, objectProp };

  console.log(object);
}
