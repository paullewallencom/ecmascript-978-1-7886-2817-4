class Rocket {}

export function main() {
  const saturnV = new Rocket();
  const falconHeavy = new Rocket();
  console.log(saturnV);
  console.log(falconHeavy);
}